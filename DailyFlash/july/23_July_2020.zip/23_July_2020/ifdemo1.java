class IfDemo{


    public static void main(String[] args) {
        
        int x=10,y=20;
        if (x <y){
            System.out.println("x is smaller");
        }
        System.out.println("out of if stattement");
    }
}