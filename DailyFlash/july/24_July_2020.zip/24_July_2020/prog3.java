class Number{

    public static void main(String[] args) {
        
        int x = 20 ,y=20;

        if(x>y)
            System.out.println("x is greater y");
        else if(x<y)
            System.out.println("x is less than y");
        else
            System.out.println("x is equal to y");


    }
}