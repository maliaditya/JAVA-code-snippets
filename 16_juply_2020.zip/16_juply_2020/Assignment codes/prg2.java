class ArithmeticDemo{

    public static void main(String[] args){

        int num1 = 20;
        int num2 = 30;
        int ans = 0;

        ans  =  num1 + num2;
        System.out.println("Addtion = " + ans);

        ans  =  num1 + num2;
        System.out.println("ubtraction = " + ans);

        ans  =  num1 * num2;
        System.out.println("Multiplication = " + ans);

        ans  =  num1 / num2;
        System.out.println("Division = " + ans);

        ans  =  num1 % num2;
        System.out.println("Modulas = " + ans);

     }
}