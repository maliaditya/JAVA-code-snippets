class Ternary{


    public static void main(String[] args) {
        boolean bVar= true;
        boolean bVar2= false;
        char cVar= 's';
        int iVar = 0;

        System.out.println(bVar == bVar2? (char)(iVar):cVar);

    }
}