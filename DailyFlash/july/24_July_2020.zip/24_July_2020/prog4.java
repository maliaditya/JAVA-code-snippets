class Vowels{

    public static void main(String[] args) {
        char c = 'a';
        
    if(c == 'a' || c == 'e'|| c == 'i'  || c == 'o'  || c == 'u' ){
        System.out.println(c + " is a Vowel");
    }
    else
    System.out.println(c + " is a Consonant");


    }
}