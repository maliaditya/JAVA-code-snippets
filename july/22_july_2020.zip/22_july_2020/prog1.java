class Ternary{

    public static void main(String[] args){

        int x = 3;

        String ans = null;

        ans = (x%2 == 0) ?  "Even Number" : "Odd Number";

        System.out.println(ans);
        
    }
}