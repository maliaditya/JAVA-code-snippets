class Ten{

    public static void main(String[] args) {
        
        for(int i = 1;i<11; i++){
            int n = 11 -i;
            System.out.println(i + " + " + n +" = " + (int)(i + n)); 
        }
    }
}