class UnaryDemo {

    public static void main(String[] args){

        boolean num = true;
        //System.out.println(++num);
        //System.out.println(++num);
        System.out.println(!num);
        
    }
    
}