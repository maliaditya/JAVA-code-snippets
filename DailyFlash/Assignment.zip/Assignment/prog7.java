class MinimumNo{

    public static void main(String[] args) {
        
        int a =50, b= 7,c=56;

        if(a<b && a<c){
            System.out.println(" minimum number from 50 7 and 56 is " + a + ".");
        } else if(b<a && b<c){
            System.out.println(" minimum number from 50 7 and 56 is " + b + ".");

        }else{
            System.out.println(" minimum number from 50 7 and 56 is " + c + ".");

        }
    }
}