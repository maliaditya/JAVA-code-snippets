class BooleanDemo{

    public static void main(String[] args){

        boolean x = true;
        //boolean y = 0;  // incompatible types: int cannot be converted to boolean
        System.out.println(x);
        //System.out.println(y); 
    }
}