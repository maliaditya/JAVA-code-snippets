

class CharDemo {
    public static void main(String[] args){

        char s = 'b';
        char a = 90;  //Z
        char d = 65;   //A
        System.out.println(s);
        System.out.println(a);
        System.out.println(d);
    }
    
}