class Voters{

    public static void main(String[] args){

        int age = 18;

        String ans = null;

        ans = (age >= 18) ? "User is Eligible" : "User is not eligible";
        System.out.println(ans);
    }
}