// In this program we are going to see what all things comes automatically in a java program 
// will be displayed exclusively in comments

// import java.lang.*

class Automatic_includes {     // class Automaticincludes extends Object
    
    /*Automatic_includes(){
          invokespecial = super()
          return  
     }*/

     public static void main(String[] Args){

            System.out.println("check out the byte code you can see it here");
            System.out.println("use this command: javap -c Automatic_includes.class");
     }
    


}