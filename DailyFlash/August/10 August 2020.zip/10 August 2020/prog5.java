class ReverseTable{

    public static void main(String[] args) {
        
        int i =10, num=4;

        while(i>0){

            System.out.print(num * i + "  ");
            i--; 
        }
    }
}