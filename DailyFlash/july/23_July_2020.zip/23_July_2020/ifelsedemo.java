class IfElseDemo1{

    public static void main(String[] args) {
        
        int x =10;

        if(x == 10)
            System.out.println("In if statement");
            System.out.println("Hello");

        System.out.println("out of if");
            
    }
}