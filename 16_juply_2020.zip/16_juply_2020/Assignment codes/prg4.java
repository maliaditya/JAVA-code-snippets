class Demo2{

    public static void main(String[] args){

        int a = 10;
        int b = 20;
        int c = 50;

        int ans = --a + ++b+ c--;
        
        System.out.println(ans);

    }
}

// ANSWER = 80
