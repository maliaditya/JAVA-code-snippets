class SwitchDemo {

    public static void main(String[] args) {

        //short x = 100;
        //byte x =100;

        //char x = 'A';

        //int  x =10;
         //boolean x = true;     error: incompatible types: boolean cannot be converted to int
        // double x = 10;  error: incompatible types: boolean cannot be converted to int
         // float x = 11; error: incompatible types: possible lossy conversion from float to int
         // long x = 11; error: incompatible types: possible lossy conversion from float to int


        switch(x){

            case 65 : 
                System.out.println("First CASE");
                break;
            case 'B' : 
                System.out.println("First CASE");
                break;
        }
    } 
}
