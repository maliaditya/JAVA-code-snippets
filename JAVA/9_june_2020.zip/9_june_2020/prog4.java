
class FloatDemo {
    
    public static void main(String[] args){

        float a = 90.6f;  
      
        System.out.println(a);

        Double v = 90.6;  
      
        System.out.println(v);

        if(a==v){
            System.out.println("same val");
        }
        else{
            System.out.println("diff val");
        }

    }
}