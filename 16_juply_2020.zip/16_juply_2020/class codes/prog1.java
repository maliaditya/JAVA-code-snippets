class AssignmentDemo{

    public static void main(String[] args){

        int age = 21;
        System.out.println("Age = " + age);
    }
}