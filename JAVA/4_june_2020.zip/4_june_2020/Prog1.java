class Hostel{

	int room_no = 506;

 static String name = "Balaji Boys Hostel";

	void memories(){

		System.out.println("Missing Hostel Friends");

	}

	static void college(){
	
			System.out.println("September parant college bandhach rahudhe");
	
		}
}
class newclass{
	public static void main(String[] args){
	
	Hostel obj = new Hostel();
	obj.memories();

	obj.college();


	}

}
	
