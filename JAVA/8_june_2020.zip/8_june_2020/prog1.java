class Demo{

    public static void main(String[] args){

        System.out.println(Integer.SIZE/8); //4
        System.out.println(Float.SIZE/8);  //4
        //System.out.println(Boolean.SIZE);
        System.out.println(Double.SIZE/8);//8
        System.out.println(Byte.SIZE/8);//1
        System.out.println(Short.SIZE/8);//2
        System.out.println(Long.SIZE/8);//8
        System.out.println(Character.SIZE/8);//2


    } 
}