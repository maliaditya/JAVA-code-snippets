class fordemo {

    public static void main(String[] args) {
        System.out.println("num" + " " + "Squares" + " " + "Cubes");
        
        for(int i=1;i<=10;i++){
            System.out.println(" " +i + "      " + i*i + "      " + i*i*i);
        }
    }
    
}