class fordemo2 {

    
    public static void main(String[] args) {
        
        for(int i=0;i<100;i++){
            if(i%4 == 0 &&  i %12 == 0){
                System.out.println(i);
            }
        }
    }
}