class SwitchDemo {

    public static void main(String[] args) {

        //short x = 100;
        //byte x =100;

        char x = 65535;
        switch(x){

            case 65 : 
                System.out.println("First CASE");
                break;
            case 'B' : 
                System.out.println("First CASE");
                break;
        }
    } 
}
